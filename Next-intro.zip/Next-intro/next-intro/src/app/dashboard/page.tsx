export default function Dashboard() {
  <h1>Dashboard</h1>;
}
