export default function Loading() {
    return (
      <>
        <h4>Loading analytics...</h4>
      </>
    );
  }
  