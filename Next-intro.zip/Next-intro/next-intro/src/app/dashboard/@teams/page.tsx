export default function Team(){
    return <p>Teams Section</p>
}