export default function NotFound() {
  return (
    <>
      <h4>Requested page not found</h4>
    </>
  );
}
