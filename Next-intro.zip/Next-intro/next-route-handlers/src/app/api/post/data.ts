export let posts = [
  {
    id: 1,
    content: "p1",
  },
  {
    id: 2,
    content: "p2",
  },
];
