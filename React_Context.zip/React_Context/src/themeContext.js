import { createContext } from "react";
const ThemeContext = createContext('light'); // Default light

export default ThemeContext;
