import "./Navbar.scss";
import CartItems from "./CartItems";

function Cart() {
  return (
    <div className="cart-main">
      <h4 className="cart-heading">Your Shopping Cart</h4>
      <CartItems />
      <CartItems />
      <CartItems />
    </div>
  );
}

export default Cart;
