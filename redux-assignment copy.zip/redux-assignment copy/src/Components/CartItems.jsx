function CartItems() {
  return (
    <div className="cart-item-main">
      <div className="cart-product-details">
        <p className="cart-product-name">Man Perfume</p>
        <div className="cart-product-price">
          <p>$54.00</p>
          <span className="cart-product-price-suffix">($6.0/item)</span>
        </div>
      </div>

      <div className="cart-item-actions">
        <div className="qty">
          <span className="qty-prefix">x</span>9
        </div>
        <div className="cart-btns">
          <button className="action-btn">-</button>
          <button className="action-btn">+</button>
        </div>
      </div>
    </div>
  );
}

export default CartItems;
