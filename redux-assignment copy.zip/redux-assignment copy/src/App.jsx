import Cart from "./Components/Cart";
import Navbar from "./Components/Navbar";


function App() {
  return (
    <div className="main-el">
      <Navbar/>
      <Cart />
    </div>
  );
}

export default App;
